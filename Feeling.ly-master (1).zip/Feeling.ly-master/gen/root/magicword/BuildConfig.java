/** Automatically generated file. DO NOT MODIFY */
package root.magicword;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}